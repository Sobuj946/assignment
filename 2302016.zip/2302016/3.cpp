#include <iostream>
#include <vector>
using namespace std;

class Distance {
public:
    int feet;
    float inches;

    Distance() : feet(0), inches(0.0) {}

    void getdata() {
        cout << "Enter feet: ";
        cin >> feet;
        cout << "Enter inches: ";
        cin >> inches;
    }

    void putdata() const {
        cout << feet << " feet, " << inches << " inches" << endl;
    }

    void add_dist(const Distance& d2) {
        inches += d2.inches;
        feet += d2.feet + int(inches / 12);
        inches = fmod(inches, 12);
    }

    void div_dist(const Distance& d2, int divisor) {
        float fltfeet = d2.feet + d2.inches / 12.0;
        fltfeet /= divisor;
        feet = int(fltfeet);
        inches = (fltfeet - feet) * 12.0;
    }
};

int main() {
    vector<Distance> distances;
    int numDistances;

    cout << "Enter the number of distances: ";
    cin >> numDistances;

    for (int i = 0; i < numDistances; i++) {
        Distance d;
        cout << "Enter distance " << i + 1 << ":\n";
        d.getdata();
        distances.push_back(d);
    }

    Distance total;
    for (int i = 0; i < numDistances; i++) {
        total.add_dist(distances[i]);
    }

    Distance average;
    average.div_dist(total, numDistances);

    cout << "\nTotal distance: ";
    total.putdata();

    cout << "Average distance: ";
    average.putdata();

    return 0;
}
