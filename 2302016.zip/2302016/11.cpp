#include <iostream>
#include <sstream>
#include <iomanip>
using namespace std;

string ldtoms(long double value) {
    if (value > 9999999999999990.00) {
        return "Error: Value too large to convert";
    }

    ostringstream ustring;
    ustring << fixed << setprecision(2) << value;
    string numStr = ustring.str();

    string result = "$";
    int pos = numStr.find('.');
    string wholePart = numStr.substr(0, pos);
    string decimalPart = numStr.substr(pos);

    int count = 0;
    for (int i = wholePart.size() - 1; i >= 0; i--) {
        result = wholePart[i] + result;
        count++;
        if (count % 3 == 0 && i > 0) {
            result = "," + result;
        }
    }

    result += decimalPart;
    return result;
}

int main() {
    long double value;
    cout << "Enter a monetary amount: ";
    while (cin >> value) {
        cout << "Formatted money string: " << ldtoms(value) << endl;
        cout << "Enter another monetary amount (or Ctrl+C to exit): ";
    }
    return 0;
}
