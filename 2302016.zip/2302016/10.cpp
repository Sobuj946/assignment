#include <iostream>
using namespace std;

class matrix {
private:
    int arr[10][10]; // Fixed-size 10x10 array
    int rows, cols;  // Actual dimensions

public:
    // Constructor to initialize matrix with given dimensions
    matrix(int r, int c) {
        if (r > 10 || c > 10) {
            cout << "Error: Matrix size exceeds 10x10 limit!" << endl;
            exit(1);
        }
        rows = r;
        cols = c;
        // Initialize matrix with zero
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                arr[i][j] = 0;
    }

    // Function to insert an element into the matrix
    void putel(int r, int c, int value) {
        if (r >= rows || c >= cols || r < 0 || c < 0) {
            cout << "Error: Index out of bounds!" << endl;
            exit(1);
        }
        arr[r][c] = value;
    }

    // Function to retrieve an element from the matrix
    int getel(int r, int c) {
        if (r >= rows || c >= cols || r < 0 || c < 0) {
            cout << "Error: Index out of bounds!" << endl;
            exit(1);
        }
        return arr[r][c];
    }
};

int main() {
    matrix m1(3, 4); // Define a 3x4 matrix
    int temp = 12345;
    m1.putel(2, 3, temp); // Insert value at (2,3)
    temp = m1.getel(2, 3); // Retrieve value from (2,3)
    cout << "Retrieved value: " << temp << endl;

    return 0;
}
