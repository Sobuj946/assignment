#include <iostream>
using namespace std;

class queue {
private:
    static const int MAX = 10;
    int arr[MAX]; // Fixed-size array for queue
    int head, tail, count; // Pointers and size counter

public:
    // Constructor to initialize queue
    queue() {
        head = 0;
        tail = -1;
        count = 0;
    }

    // Function to add an element to the queue
    void put(int value) {
        if (count == MAX) {
            cout << "Error: Queue is full!" << endl;
            return;
        }
        tail = (tail + 1) % MAX; // Wrap around if needed
        arr[tail] = value;
        count++;
    }

    // Function to retrieve an element from the queue
    int get() {
        if (count == 0) {
            cout << "Error: Queue is empty!" << endl;
            exit(1);
        }
        int value = arr[head];
        head = (head + 1) % MAX; // Wrap around if needed
        count--;
        return value;
    }
};

int main() {
    queue q;
    q.put(10);
    q.put(20);
    q.put(30);

    cout << "Retrieved value: " << q.get() << endl;
    cout << "Retrieved value: " << q.get() << endl;
    cout << "Retrieved value: " << q.get() << endl;

    return 0;
}
