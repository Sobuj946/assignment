#include <iostream>
#include <algorithm>
#include <ctime>

using namespace std;

class Card {
public:
    string rank, suit;
    Card() {}
    Card(string r, string s) : rank(r), suit(s) {}
};

class Deck {
private:
    Card cards[52];
public:
    Deck() {
        string ranks[] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        string suits[] = {"Hearts", "Diamonds", "Clubs", "Spades"};
        int index = 0;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 13; j++) {
                cards[index++] = Card(ranks[j], suits[i]);
            }
        }
    }

    void shuffleDeck() {
        srand(time(0));
        for (int i = 51; i > 0; i--) {
            int j = rand() % (i + 1);
            swap(cards[i], cards[j]);
        }
    }

    Card getCard(int index) {
        return cards[index];
    }
};

class Player {
private:
    Card hand[13];
public:
    void receiveCard(Card card, int index) {
        hand[index] = card;
    }

    void displayHand(int playerNumber) {
        cout << "Player " << playerNumber << "'s hand:\n";
        for (int i = 0; i < 13; i++) {
            cout << hand[i].rank << " of " << hand[i].suit << "\n";
        }
        cout << "\n";
    }
};

class BridgeGame {
private:
    Deck deck;
    Player players[4];
public:
    void dealCards() {
        for (int i = 0; i < 52; i++) {
            players[i % 4].receiveCard(deck.getCard(i), i / 4);
        }
    }

    void play() {
        deck.shuffleDeck();
        dealCards();
        for (int i = 0; i < 4; i++) {
            players[i].displayHand(i + 1);
        }
    }
};

int main() {
    BridgeGame game;
    game.play();
    return 0;
}
