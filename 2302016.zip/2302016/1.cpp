#include <iostream>
#include <cstring>
using namespace std;

void reversit(char str[]) {
    int len = strlen(str); // Get the length of the string
    for (int i = 0; i < len / 2; i++) {
        // Swap the characters at positions i and len-i-1
        char temp = str[i];
        str[i] = str[len - i - 1];
        str[len - i - 1] = temp;
    }
}

int main() {
    // Ask the user for a string (allowing embedded blanks)
    cout << "Enter a string: ";
    char str[200]; // Array to hold the user input
    cin.getline(str, 200); // Use getline to capture a string with spaces

    // Call reversit function
    reversit(str);

    // Output the reversed string
    cout << "Reversed string: " << str << endl;

    return 0;
}
