#include <iostream>
using namespace std;

int maxint(int arr[], int size) {
    int maxIndex = 0;
    for (int i = 1; i < size; i++) {
        if (arr[i] > arr[maxIndex]) {
            maxIndex = i;
        }
    }
    return maxIndex;
}

int main() {
    int numElements;

    cout << "Enter the number of integers: ";
    cin >> numElements;

    int arr[numElements];

    cout << "Enter the integers:" << endl;
    for (int i = 0; i < numElements; i++) {
        cin >> arr[i];
    }

    int index = maxint(arr, numElements);
    cout << "The largest number is " << arr[index] << " at index " << index << "." << endl;

    return 0;
}
