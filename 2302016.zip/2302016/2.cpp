#include <iostream>
#include <string>
using namespace std;

class Employee {
public:
    string name;
    long employeeNumber;

    void getdata() {
        cout << "Enter name: ";
        cin >> name;
        cout << "Enter employee number: ";
        cin >> employeeNumber;
    }

    void putdata() {
        cout << "Name: " << name << ", Employee Number: " << employeeNumber << endl;
    }
};

int main() {
    Employee employees[100];
    int numEmployees;

    cout << "Enter the number of employees: ";
    cin >> numEmployees;

    for (int i = 0; i < numEmployees; i++) {
        cout << "Enter data for employee " << i + 1 << endl;
        employees[i].getdata();
    }

    cout << "\nEmployee data:\n";
    for (int i = 0; i < numEmployees; i++) {
        employees[i].putdata();
    }

    return 0;
}
